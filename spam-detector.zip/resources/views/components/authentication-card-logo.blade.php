<a href="/">
    <img src="{{ asset('assets/images/bug.png') }}" alt="Logo" style="width: 30px; height: 30px;">
</a>
