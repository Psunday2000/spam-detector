<a href="/">
    <img src="<?php echo e(asset('assets/images/bug.png')); ?>" alt="Logo" style="width: 30px; height: 30px;">
</a>
<?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>