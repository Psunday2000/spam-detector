

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 p-2" id="email-nav-mobile">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true" hidden>&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="d-flex flex-row justify-content-between">
                <div class="p-2">
                    <h5>Emails</h5>
                </div>
                <div class="p-2">
                    <a class="btn btn-primary" href="<?php echo e(route('emails.create')); ?>">New Email</a>
                </div>
            </div>
            <div id="email-nav">
                <a href="<?php echo e(route('emails.index')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.index') ? 'active' : ''); ?>" aria-current="page">
                    <div class="p-2">
                        <span>Inbox</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($inbox_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.sent')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.sent') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Sent</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($sent_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.spam')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.spam') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Spam</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($spam_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.trash')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.trash') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Trash</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($trash_count); ?></span>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-md-3 p-2" id="email-navi-desktop">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close" hidden>
                        <span aria-hidden="true" hidden>&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="d-flex flex-row justify-content-between">
                <div class="p-2">
                    <h5>Emails</h5>
                </div>
                <div class="p-2">
                    <a class="btn btn-primary" href="<?php echo e(route('emails.create')); ?>">New Email</a>
                </div>
            </div>
            <div class="list-group" id="email-nav-desktop">
                <a href="<?php echo e(route('emails.index')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.index') ? 'active' : ''); ?>" aria-current="page">
                    <div class="p-2">
                        <span>Inbox</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($inbox_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.sent')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.sent') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Sent</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($sent_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.spam')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.spam') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Spam</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($spam_count); ?></span>
                    </div>
                </a>
                <a href="<?php echo e(route('emails.trash')); ?>" class="list-group-div <?php echo e(request()->routeIs('emails.trash') ? 'active' : ''); ?>">
                    <div class="p-2">
                        <span>Trash</span>
                    </div>
                    <div class="p-2">
                        <span class="count-badge"><?php echo e($trash_count); ?></span>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-md-9 p-2 email-bar">
            <?php if($emails->count() > 0): ?>
            <div class="table-responsive">
                <?php if($emails->count() > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <?php if(Route::currentRouteName() !== 'emails.sent'): ?>
                                <th scope="col">Sender</th>
                                <th scope="col">Subject</th>
                                <th scope="col">Action</th>
                            <?php endif; ?>
                            <?php if(Route::currentRouteName() == 'emails.sent'): ?>
                                <th scope="col">Receiver</th>
                                <th scope="col">Subject</th>
                                <th scope="col">Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if(Route::currentRouteName() !== 'emails.sent'): ?>
                                <td><?php echo e($email->sender_email); ?></td>
                                <td><?php echo e($email->subject); ?></td>
                                <td>
                                    <div class="d-flex flex-row justify-content-center">                                            
                                        <?php if(Route::currentRouteName() !== 'emails.trash'): ?>
                                        <div class="p-2">
                                            <a href="<?php echo e(route('emails.show', $email->id)); ?>"><i class="action-btn fa-solid fa-desktop"></i></a>
                                        </div>
                                        <div class="p-2">
                                            <form id="delete-form-<?php echo e($email->id); ?>" action="<?php echo e(route('emails.softDelete', $email->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                            <a href="" onclick="event.preventDefault(); if (confirm('Are you sure you want to delete this email?')) { document.getElementById('delete-form-<?php echo e($email->id); ?>').submit(); }"><i style="color: #e80721;" class="action-btn fa-solid fa-trash"></i></a>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(Route::currentRouteName() == 'emails.trash'): ?>
                                            <div class="p-2">
                                                <form id="restore-form-<?php echo e($email->id); ?>" action="<?php echo e(route('emails.restore', $email->id)); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                </form>
                                                <a href="" onclick="event.preventDefault(); if (confirm('Are you sure you want to restore this email?')) { document.getElementById('restore-form-<?php echo e($email->id); ?>').submit(); }"><i class="action-btn fa-solid fa-trash-can-arrow-up"></i></a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            <?php endif; ?>
                            <?php if(Route::currentRouteName() == 'emails.sent'): ?>
                            <td><?php echo e($email->receiver_email); ?></td>
                            <td><?php echo e($email->subject); ?></td>
                            <td>
                                <div class="d-flex flex-row justify-content-center">                                            
                                    <?php if(Route::currentRouteName() !== 'emails.trash'): ?>
                                    <div class="p-2">
                                        <a href="<?php echo e(route('emails.show', $email->id)); ?>"><i class="action-btn fa-solid fa-desktop"></i></a>
                                    </div>
                                    <div class="p-2">
                                        <form id="delete-form-<?php echo e($email->id); ?>" action="<?php echo e(route('emails.softDelete', $email->id)); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                        <a href="" onclick="event.preventDefault(); if (confirm('Are you sure you want to delete this email?')) { document.getElementById('delete-form-<?php echo e($email->id); ?>').submit(); }"><i style="color: #e80721;" class="action-btn fa-solid fa-trash"></i></a>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(Route::currentRouteName() == 'emails.trash'): ?>
                                        <div class="p-2">
                                            <form id="restore-form-<?php echo e($email->id); ?>" action="<?php echo e(route('emails.restore', $email->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                            </form>
                                            <a href="" onclick="event.preventDefault(); if (confirm('Are you sure you want to restore this email?')) { document.getElementById('restore-form-<?php echo e($email->id); ?>').submit(); }"><i class="action-btn fa-solid fa-trash-can-arrow-up"></i></a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <h5 style="text-align:center; font-size: 50pt;">
                <i id="sad-tear" class="fa-solid fa-face-sad-tear"></i>
            </h5>
            <h5 style="text-align:center;">Sorry no emails here!</h5>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/emails/index.blade.php ENDPATH**/ ?>