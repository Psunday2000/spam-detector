

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Add New Email</h2>
    <form id="email-form" action="<?php echo e(route('emails.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
        <input type="hidden" name="sender_email" value="<?php echo e(auth()->user()->email); ?>">
        <div class="mb-3">
            <label for="receiver_email" class="form-label">Receiver Email</label>
            <select class="form-control select2" id="receiver_email" name="receiver_email" required>
                <option value="" disabled selected>Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->email != auth()->user()->email): ?>
                        <option value="<?php echo e($user->email); ?>"><?php echo e($user->email); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>            
        </div>        
        <div class="mb-3">
            <label for="subject" class="form-label">Subject</label>
            <input type="text" class="form-control" id="subject" name="subject" required>
        </div>
        <div class="mb-3">
            <label for="body" class="form-label">Body</label>
            <textarea class="form-control" id="body" name="body" rows="5" required></textarea>
        </div>
        <input type="submit" class="btn btn-primary" id="submit" name="submit" value="Send">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/emails/create.blade.php ENDPATH**/ ?>