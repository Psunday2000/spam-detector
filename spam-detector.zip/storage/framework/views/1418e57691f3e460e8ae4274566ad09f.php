

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Upload Emails</h2>
    <form action="<?php echo e(route('emails.upload')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="emails" class="form-label">Email File (TXT or CSV)</label>
            <input type="file" class="form-control" id="emails" name="emails" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/emails/upload.blade.php ENDPATH**/ ?>