

<?php $__env->startSection('content'); ?>
<div class="container d-flex flex-column justify-content-center" style="min-height: 100vh;">
    <div class="p-2">
        <a style="text-decoration: none; color:black;" href="<?php echo e(url()->previous()); ?>"><i class="fa-solid fa-arrow-left"></i> Back</a>
    </div>
    <div class="card">
        <div class="card-header"><h5 style="text-align: center;"><?php echo e($email->subject); ?></h5></div>
        <div class="card-body">
            <p><strong>Sender:</strong> <?php echo e($email->sender_email); ?></p>
            <p><strong>Receiver:</strong> <?php echo e($email->receiver_email); ?></p>
            <p><strong><hr></strong></p>
            <p class="email-body"><?php echo e($email->body); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/emails/show.blade.php ENDPATH**/ ?>