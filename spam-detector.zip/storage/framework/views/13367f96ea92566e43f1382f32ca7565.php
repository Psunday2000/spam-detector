<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><strong><h5>Profile Information</h5></strong></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('update-profile')); ?>">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name', auth()->user()->name)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
                            <input id="password" type="password" class="form-control" name="password" autocomplete="new-password">
                        </div>

                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                            <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                        </div>

                        <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/profile/update-profile-information-form.blade.php ENDPATH**/ ?>