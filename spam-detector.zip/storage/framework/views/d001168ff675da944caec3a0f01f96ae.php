

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <?php if(auth()->guard()->check()): ?>
                <div class="d-flex flex-column justify-content-center">
                    <div class="p-2 text-center">
                        <img src="<?php echo e(asset('assets/images/bug.png')); ?>" alt="Logo" style="width: 50px; height: 50px;">
                        <h5><strong><?php echo e(config('app.name', 'Laravel')); ?></strong></h5><br>
                    </div>
                    <div class="p-2">
                        <?php echo $__env->make('profile.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            <?php else: ?>
                <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Github\spam-detector\resources\views/home.blade.php ENDPATH**/ ?>